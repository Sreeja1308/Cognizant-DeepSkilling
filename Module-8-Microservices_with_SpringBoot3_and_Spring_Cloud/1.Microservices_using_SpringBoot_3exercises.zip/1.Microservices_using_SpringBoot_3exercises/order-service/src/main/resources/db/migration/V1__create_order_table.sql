-- Create order table
CREATE TABLE IF NOT EXISTS orders (
                                      id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                      user_id BIGINT NOT NULL,
                                      product_name VARCHAR(200) NOT NULL,
    quantity INT NOT NULL,
    total_price DECIMAL(10, 2) NOT NULL,
    status VARCHAR(50) DEFAULT 'PLACED',
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_order_user_id (user_id),
    INDEX idx_order_status (status),
    INDEX idx_order_date (order_date),
    CONSTRAINT chk_order_quantity CHECK (quantity > 0),
    CONSTRAINT chk_order_price CHECK (total_price >= 0)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert sample orders
INSERT INTO orders (user_id, product_name, quantity, total_price, status) VALUES
                                                                              (1, 'Laptop Pro', 1, 1299.99, 'PLACED'),
                                                                              (1, 'Wireless Mouse', 2, 59.98, 'SHIPPED'),
                                                                              (2, 'Monitor 27"', 1, 349.99, 'DELIVERED'),
                                                                              (2, 'Keyboard', 1, 89.99, 'PLACED'),
                                                                              (3, 'USB-C Hub', 3, 149.97, 'CANCELLED');