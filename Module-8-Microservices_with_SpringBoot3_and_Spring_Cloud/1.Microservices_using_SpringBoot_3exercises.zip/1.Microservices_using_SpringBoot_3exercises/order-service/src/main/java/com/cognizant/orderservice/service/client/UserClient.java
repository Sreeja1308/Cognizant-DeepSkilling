package com.example.orderservice.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

@Component
public class UserClient {
    @Autowired
    private WebClient webClient;

    public boolean userExists(Long userId) {
        try {
            return webClient.get()
                    .uri("http://USER-SERVICE/users/" + userId)
                    .retrieve()
                    .toBodilessEntity()
                    .block() != null;
        } catch (Exception e) {
            return false;
        }
    }
}