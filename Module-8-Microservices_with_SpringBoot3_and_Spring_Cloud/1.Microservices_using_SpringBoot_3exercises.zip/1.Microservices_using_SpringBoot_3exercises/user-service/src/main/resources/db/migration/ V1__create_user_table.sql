-- Create user table
CREATE TABLE IF NOT EXISTS users (
                                     id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                     name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_email (email)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert sample users
INSERT INTO users (name, email, phone) VALUES
                                           ('John Doe', 'john.doe@example.com', '+1234567890'),
                                           ('Jane Smith', 'jane.smith@example.com', '+1234567891'),
                                           ('Bob Johnson', 'bob.johnson@example.com', '+1234567892'),
                                           ('Alice Williams', 'alice.williams@example.com', '+1234567893'),
                                           ('Charlie Brown', 'charlie.brown@example.com', '+1234567894');