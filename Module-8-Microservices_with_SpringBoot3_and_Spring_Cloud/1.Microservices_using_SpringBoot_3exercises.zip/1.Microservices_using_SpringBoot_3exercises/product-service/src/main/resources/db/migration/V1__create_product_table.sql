-- Create product table
CREATE TABLE IF NOT EXISTS products (
                                        id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                        name VARCHAR(200) NOT NULL,
                                        description TEXT,
                                        price DECIMAL(10, 2) NOT NULL,
                                        category VARCHAR(100),
                                        sku VARCHAR(50) UNIQUE,
                                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                                        INDEX idx_product_name (name),
                                        INDEX idx_product_category (category),
                                        INDEX idx_product_sku (sku),
                                        CONSTRAINT chk_product_price CHECK (price >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert sample products
INSERT INTO products (name, description, price, category, sku) VALUES
                                                                   ('Laptop Pro', 'High-performance laptop with 16GB RAM, 512GB SSD', 1299.99, 'Electronics', 'LAP-001'),
                                                                   ('Wireless Mouse', 'Ergonomic wireless mouse with Bluetooth 5.0', 29.99, 'Accessories', 'MOU-001'),
                                                                   ('Monitor 27"', '4K UHD Monitor with HDR support', 349.99, 'Electronics', 'MON-001'),
                                                                   ('Mechanical Keyboard', 'RGB mechanical keyboard with Cherry MX switches', 89.99, 'Accessories', 'KEY-001'),
                                                                   ('USB-C Hub', '7-in-1 USB-C hub with HDMI, USB 3.0, and SD card reader', 49.99, 'Accessories', 'HUB-001'),
                                                                   ('External SSD', '1TB Portable SSD with USB 3.2', 159.99, 'Storage', 'SSD-001'),
                                                                   ('Webcam 4K', '4K Ultra HD Webcam with microphone', 199.99, 'Electronics', 'CAM-001'),
                                                                   ('Noise Cancelling Headphones', 'Wireless noise cancelling headphones', 249.99, 'Audio', 'HPH-001');