-- Create inventory table
CREATE TABLE IF NOT EXISTS inventory (
                                         id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                         product_id BIGINT NOT NULL UNIQUE,
                                         stock_quantity INT NOT NULL DEFAULT 0,
                                         reserved_quantity INT NOT NULL DEFAULT 0,
                                         reorder_level INT NOT NULL DEFAULT 10,
                                         reorder_quantity INT NOT NULL DEFAULT 50,
                                         last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                                         INDEX idx_inventory_product_id (product_id),
                                         INDEX idx_inventory_reorder_level (reorder_level),
                                         CONSTRAINT chk_inventory_stock CHECK (stock_quantity >= 0),
                                         CONSTRAINT chk_inventory_reserved CHECK (reserved_quantity >= 0),
                                         CONSTRAINT chk_inventory_reorder_level CHECK (reorder_level >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert sample inventory
INSERT INTO inventory (product_id, stock_quantity, reserved_quantity, reorder_level, reorder_quantity) VALUES
                                                                                                           (1, 50, 5, 10, 20),
                                                                                                           (2, 200, 10, 30, 50),
                                                                                                           (3, 30, 3, 10, 15),
                                                                                                           (4, 100, 8, 20, 30),
                                                                                                           (5, 75, 2, 15, 25),
                                                                                                           (6, 40, 1, 10, 20),
                                                                                                           (7, 25, 0, 5, 15),
                                                                                                           (8, 60, 4, 10, 20);