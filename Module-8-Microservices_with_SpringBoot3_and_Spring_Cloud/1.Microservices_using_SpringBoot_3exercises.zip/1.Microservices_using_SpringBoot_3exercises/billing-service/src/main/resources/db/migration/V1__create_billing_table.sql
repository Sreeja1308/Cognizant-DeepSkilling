-- Create billing table
CREATE TABLE IF NOT EXISTS bills (
                                     id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                     customer_id BIGINT NOT NULL,
                                     invoice_number VARCHAR(50) NOT NULL UNIQUE,
                                     amount DECIMAL(10, 2) NOT NULL,
                                     tax_amount DECIMAL(10, 2) DEFAULT 0.00,
                                     total_amount DECIMAL(10, 2) NOT NULL,
                                     description TEXT,
                                     status VARCHAR(50) DEFAULT 'PENDING',
                                     bill_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                     due_date TIMESTAMP,
                                     paid_date TIMESTAMP,
                                     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                     updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                                     INDEX idx_bill_customer_id (customer_id),
                                     INDEX idx_bill_invoice_number (invoice_number),
                                     INDEX idx_bill_status (status),
                                     INDEX idx_bill_date (bill_date),
                                     INDEX idx_bill_due_date (due_date),
                                     CONSTRAINT chk_bill_amount CHECK (amount >= 0),
                                     CONSTRAINT chk_bill_tax CHECK (tax_amount >= 0),
                                     CONSTRAINT chk_bill_total CHECK (total_amount >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert sample bills
INSERT INTO bills (customer_id, invoice_number, amount, tax_amount, total_amount, description, status, due_date) VALUES
                                                                                                                     (1, 'INV-2024-001', 299.99, 23.99, 323.98, 'Monthly subscription - Premium Plan', 'PAID', DATE_ADD(NOW(), INTERVAL 30 DAY)),
                                                                                                                     (2, 'INV-2024-002', 149.99, 11.99, 161.98, 'Product purchase - Electronics', 'PENDING', DATE_ADD(NOW(), INTERVAL 15 DAY)),
                                                                                                                     (3, 'INV-2024-003', 499.99, 39.99, 539.98, 'Annual membership fee', 'PENDING', DATE_ADD(NOW(), INTERVAL 45 DAY)),
                                                                                                                     (4, 'INV-2024-004', 89.99, 7.20, 97.19, 'Service charge - Consulting', 'OVERDUE', DATE_SUB(NOW(), INTERVAL 10 DAY)),
                                                                                                                     (5, 'INV-2024-005', 199.99, 15.99, 215.98, 'Product purchase - Accessories', 'PAID', DATE_ADD(NOW(), INTERVAL 20 DAY));