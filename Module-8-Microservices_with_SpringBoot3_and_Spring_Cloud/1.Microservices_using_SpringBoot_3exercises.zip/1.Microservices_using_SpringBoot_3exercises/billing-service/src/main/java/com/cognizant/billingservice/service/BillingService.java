package com.cognizant.billingservice.service;

import com.cognizant.billingservice.model.Billing;
import com.cognizant.billingservice.repository.BillingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class BillingService {
    @Autowired
    private BillingRepository billingRepository;

    public List<Billing> getAllBills() {
        return billingRepository.findAll();
    }

    public Billing getBillById(Long id) {
        return billingRepository.findById(id).orElse(null);
    }

    public List<Billing> getBillsByCustomerId(Long customerId) {
        return billingRepository.findByCustomerId(customerId);
    }

    public Billing createBill(Billing billing) {
        billing.setBillDate(LocalDateTime.now());
        return billingRepository.save(billing);
    }

    public Billing updateBill(Long id, Billing billing) {
        if (billingRepository.existsById(id)) {
            billing.setId(id);
            return billingRepository.save(billing);
        }
        return null;
    }

    public void deleteBill(Long id) {
        billingRepository.deleteById(id);
    }
}