package com.cognizant.billingservice.controller;

import com.cognizant.billingservice.model.Billing;
import com.cognizant.billingservice.service.BillingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/bills")
public class BillingController {
    @Autowired
    private BillingService billingService;

    @GetMapping
    public ResponseEntity<List<Billing>> getAllBills() {
        return ResponseEntity.ok(billingService.getAllBills());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Billing> getBillById(@PathVariable Long id) {
        Billing bill = billingService.getBillById(id);
        return bill != null ? ResponseEntity.ok(bill) : ResponseEntity.notFound().build();
    }

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<Billing>> getBillsByCustomerId(@PathVariable Long customerId) {
        return ResponseEntity.ok(billingService.getBillsByCustomerId(customerId));
    }

    @PostMapping
    public ResponseEntity<Billing> createBill(@RequestBody Billing billing) {
        return ResponseEntity.status(HttpStatus.CREATED).body(billingService.createBill(billing));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Billing> updateBill(@PathVariable Long id, @RequestBody Billing billing) {
        Billing updated = billingService.updateBill(id, billing);
        return updated != null ? ResponseEntity.ok(updated) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBill(@PathVariable Long id) {
        billingService.deleteBill(id);
        return ResponseEntity.noContent().build();
    }
}