package com.cognizant.billingservice.repository;

import com.example.billingservice.model.Billing;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface BillingRepository extends JpaRepository<Billing, Long> {
    List<Billing> findByCustomerId(Long customerId);
}