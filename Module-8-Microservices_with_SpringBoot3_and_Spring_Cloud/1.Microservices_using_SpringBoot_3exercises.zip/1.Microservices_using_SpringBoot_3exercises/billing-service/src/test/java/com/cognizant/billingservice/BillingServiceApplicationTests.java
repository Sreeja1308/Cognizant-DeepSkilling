package com.cognizant.billingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BillingServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
