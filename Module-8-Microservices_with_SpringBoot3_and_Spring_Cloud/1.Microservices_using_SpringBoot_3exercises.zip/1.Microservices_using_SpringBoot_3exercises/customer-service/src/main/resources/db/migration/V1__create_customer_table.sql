-- Create customer table
CREATE TABLE IF NOT EXISTS customers (
                                         id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                         name VARCHAR(100) NOT NULL,
                                         email VARCHAR(100) NOT NULL UNIQUE,
                                         phone VARCHAR(20),
                                         address TEXT,
                                         city VARCHAR(100),
                                         state VARCHAR(50),
                                         zip_code VARCHAR(20),
                                         country VARCHAR(50) DEFAULT 'USA',
                                         customer_type VARCHAR(50) DEFAULT 'REGULAR',
                                         created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                         updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                                         INDEX idx_customer_email (email),
                                         INDEX idx_customer_name (name),
                                         INDEX idx_customer_city (city),
                                         INDEX idx_customer_type (customer_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert sample customers
INSERT INTO customers (name, email, phone, address, city, state, zip_code, customer_type) VALUES
                                                                                              ('Alice Johnson', 'alice.j@example.com', '+1234567890', '123 Main St', 'New York', 'NY', '10001', 'PREMIUM'),
                                                                                              ('Bob Smith', 'bob.smith@example.com', '+1234567891', '456 Oak Ave', 'Los Angeles', 'CA', '90001', 'REGULAR'),
                                                                                              ('Carol White', 'carol.w@example.com', '+1234567892', '789 Pine Rd', 'Chicago', 'IL', '60601', 'GOLD'),
                                                                                              ('David Brown', 'david.b@example.com', '+1234567893', '321 Elm St', 'Houston', 'TX', '77001', 'REGULAR'),
                                                                                              ('Eva Green', 'eva.g@example.com', '+1234567894', '654 Maple Dr', 'Phoenix', 'AZ', '85001', 'PREMIUM');