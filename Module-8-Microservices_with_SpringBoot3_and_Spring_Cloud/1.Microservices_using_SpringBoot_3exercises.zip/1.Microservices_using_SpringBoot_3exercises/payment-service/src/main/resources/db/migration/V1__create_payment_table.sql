-- Create payment table
CREATE TABLE IF NOT EXISTS payments (
                                        id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                        order_id BIGINT NOT NULL,
                                        amount DECIMAL(10, 2) NOT NULL,
                                        payment_method VARCHAR(50) NOT NULL,
                                        transaction_id VARCHAR(100) UNIQUE,
                                        status VARCHAR(50) DEFAULT 'PENDING',
                                        payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                        processed_date TIMESTAMP,
                                        failure_reason TEXT,
                                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                                        INDEX idx_payment_order_id (order_id),
                                        INDEX idx_payment_transaction_id (transaction_id),
                                        INDEX idx_payment_status (status),
                                        INDEX idx_payment_date (payment_date),
                                        CONSTRAINT chk_payment_amount CHECK (amount >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert sample payments
INSERT INTO payments (order_id, amount, payment_method, transaction_id, status, payment_date, processed_date) VALUES
                                                                                                                  (1, 1299.99, 'CREDIT_CARD', 'TXN-2024-001', 'SUCCESS', NOW(), NOW()),
                                                                                                                  (2, 59.98, 'DEBIT_CARD', 'TXN-2024-002', 'SUCCESS', NOW(), NOW()),
                                                                                                                  (3, 349.99, 'PAYPAL', 'TXN-2024-003', 'PENDING', NOW(), NULL),
                                                                                                                  (4, 89.99, 'CREDIT_CARD', 'TXN-2024-004', 'FAILED', NOW(), NOW()),
                                                                                                                  (5, 149.97, 'BANK_TRANSFER', 'TXN-2024-005', 'SUCCESS', NOW(), NOW());