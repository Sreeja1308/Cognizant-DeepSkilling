package com.cognizant.paymentservice.client;

import org.springframework.stereotype.Component;
import java.util.Random;

@Component
public class ThirdPartyPaymentClient {
    private final Random random = new Random();

    public boolean processPayment(Double amount) throws InterruptedException {
        // Simulate slow third-party API call
        Thread.sleep(3000 + random.nextInt(3000));

        // Simulate random failures
        if (random.nextInt(100) < 30) {
            throw new RuntimeException("Third-party payment service failed");
        }

        return true;
    }
}