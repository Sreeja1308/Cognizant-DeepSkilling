package com.cognizant.microservicesloadbalancing.model;

public class Response<T> {
    private boolean hasServer;
    private T server;

    public Response(boolean hasServer, T server) {
        this.hasServer = hasServer;
        this.server = server;
    }

    public boolean isHasServer() {
        return hasServer;
    }

    public void setHasServer(boolean hasServer) {
        this.hasServer = hasServer;
    }

    public T getServer() {
        return server;
    }

    public void setServer(T server) {
        this.server = server;
    }
}