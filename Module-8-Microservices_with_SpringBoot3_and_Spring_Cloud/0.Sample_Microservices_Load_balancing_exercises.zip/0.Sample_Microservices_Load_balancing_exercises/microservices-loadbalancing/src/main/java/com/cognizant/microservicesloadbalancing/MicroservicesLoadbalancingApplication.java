package com.cognizant.microservicesloadbalancing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicesLoadbalancingApplication {
    public static void main(String[] args) {
        SpringApplication.run(MicroservicesLoadbalancingApplication.class, args);
    }
}