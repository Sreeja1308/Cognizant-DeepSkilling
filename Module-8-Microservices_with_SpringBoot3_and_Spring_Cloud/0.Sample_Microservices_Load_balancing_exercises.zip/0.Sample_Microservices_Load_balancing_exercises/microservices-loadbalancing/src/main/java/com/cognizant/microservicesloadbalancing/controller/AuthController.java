package com.cognizant.microservicesloadbalancing.controller;

import com.cognizant.microservicesloadbalancing.provider.JwtTokenProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
public class AuthController {
    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @PostMapping("/login")
    public Mono<String> login(@RequestParam String username) {
        return Mono.just(jwtTokenProvider.createToken(username));
    }
}