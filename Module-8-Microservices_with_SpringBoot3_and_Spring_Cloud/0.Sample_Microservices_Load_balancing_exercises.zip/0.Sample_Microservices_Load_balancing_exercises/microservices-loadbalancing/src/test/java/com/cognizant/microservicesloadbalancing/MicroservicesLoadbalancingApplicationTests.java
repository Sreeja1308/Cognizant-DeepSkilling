package com.cognizant.microservicesloadbalancing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicesLoadbalancingApplicationTests {
    @Test
    void contextLoads() {
    }
}