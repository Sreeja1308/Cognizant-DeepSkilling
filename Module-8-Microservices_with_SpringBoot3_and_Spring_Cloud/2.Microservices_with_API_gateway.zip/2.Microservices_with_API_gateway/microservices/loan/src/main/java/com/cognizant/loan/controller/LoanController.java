package com.cognizant.loan.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/loans")
public class LoanController {

    @GetMapping("/{number}")
    public Map<String, Object> getLoanDetails(@PathVariable String number) {
        Map<String, Object> loan = new HashMap<>();
        loan.put("loanNumber", number);
        loan.put("loanType", "Car Loan");
        loan.put("loanAmount", 400000.00);
        loan.put("emiAmount", 3258.00);
        loan.put("tenureMonths", 18);
        loan.put("interestRate", 8.5);
        loan.put("status", "Active");
        loan.put("nextDueDate", "2026-08-15");
        return loan;
    }

    // Test endpoint to verify service is working
    @GetMapping("/test")
    public String test() {
        return "Loan Service is working!";
    }
}